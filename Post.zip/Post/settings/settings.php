<?php

$host = "localhost";
$login = "root";
$senha = "";
$banco = "login";

$conecta = mysqli_connect($host, $login, $senha, $banco) or die ('Não conectado');

?>